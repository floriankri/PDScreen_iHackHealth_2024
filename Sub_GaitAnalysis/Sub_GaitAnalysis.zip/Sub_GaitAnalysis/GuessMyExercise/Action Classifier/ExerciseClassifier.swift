//
//  ExerciseClassifier.swift
//  Guess My Exercise
//
//  Created by Florian Kristof on 02.02.24.
//  Copyright © 2024 Apple. All rights reserved.
//

import Foundation

class ExerciseClassifier {
}
